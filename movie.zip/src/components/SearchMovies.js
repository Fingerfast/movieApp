import React from 'react';

function SearchMovies() {
    return (
        <div>aaaS</div>
    );
}

export default SearchMovies;